﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ASM_APS.NetCore.Controllers
{
    public class GioHangController : Controller
    {
        private const string CartKey = "Cart";
        private readonly ApplicationDbContext _context;
        public GioHangController(ApplicationDbContext context) { _context = context; }

        private List<MucGioHang> GetCart()
        {
            var json = HttpContext.Session.GetString(CartKey);
            return string.IsNullOrEmpty(json) ? new List<MucGioHang>() : JsonSerializer.Deserialize<List<MucGioHang>>(json);
        }

        private void SaveCart(List<MucGioHang> cart)
        {
            HttpContext.Session.SetString(CartKey, JsonSerializer.Serialize(cart));
        }

        [HttpPost]
        public IActionResult ThemVaoGio(int sanPhamId, int soLuong = 1)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(c => c.SanPhamId == sanPhamId);
            if (item == null) cart.Add(new MucGioHang { SanPhamId = sanPhamId, SoLuong = soLuong });
            else item.SoLuong += soLuong;
            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            var cart = GetCart();
            var vm = new List<(SanPham product, int quantity)>();
            foreach (var it in cart)
            {
                var p = await _context.Products.FindAsync(it.SanPhamId);
                if (p != null) vm.Add((p, it.SoLuong));
            }
            return View(vm);
        }

        [HttpPost]
        public IActionResult CapNhat(int sanPhamId, int soLuong)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(c => c.SanPhamId == sanPhamId);
            if (item != null)
            {
                if (soLuong <= 0) cart.Remove(item);
                else item.SoLuong = soLuong;
                SaveCart(cart);
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Xoa(int sanPhamId)
        {
            var cart = GetCart();
            cart.RemoveAll(c => c.SanPhamId == sanPhamId);
            SaveCart(cart);
            return RedirectToAction("Index");
        }
    }
}
