﻿namespace ASM_APS.NetCore.Models
{
    public class SanPham
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        
        public string Description { get; set; }
        
        public string Brand { get; set; } 
        
        public decimal Price { get; set; } 
        public decimal OriginalPrice { get; set; } 
        public int Stock { get; set; } 
        public string ImageUrl { get; set; }
        public bool IsFeatured { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<ChiTietDonHang> ChiTietDonHangs { get; set; } = new();
        public ChiTietSanPham? ChiTietSanPham { get; set; }
    }

}
