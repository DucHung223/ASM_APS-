﻿namespace ASM_APS.NetCore.Models
{
    public class NguoiDung
    {
        public int Id { get; set; }
        public string TenDangNhap { get; set; }
        public string Email { get; set; }
        public string MatKhau { get; set; }
        public string HoTen { get; set; }
        public string VaiTro { get; set; } // "Admin" hoặc "KhachHang"
        public DateTime NgayTao { get; set; }
        public List<DonHang> DonHangs { get; set; } = new();
    }
}
