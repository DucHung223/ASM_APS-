﻿using Microsoft.EntityFrameworkCore.Query.Internal;

namespace ASM_APS.NetCore.Models
{
    public class ChiTietSanPham
    {
        public int Id { get; set; }

        public int SanPhamId { get; set; }
        public SanPham SanPham { get; set; }

        public string Pin {  get; set; }
        public string Ram { get; set; }
        public string Chip {  get; set; }
        public string Camera {  get; set; }
        public string Screen {  get; set; }
        public string Storage { get; set; }
    }
}
