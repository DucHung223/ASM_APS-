﻿using System.ComponentModel.DataAnnotations;

namespace ASM_APS.NetCore.Models
{
    public class MucGioHang
    {
        
        public int SanPhamId { get; set; }
        public int SoLuong { get; set; }
    }
}
