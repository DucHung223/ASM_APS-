﻿namespace ASM_APS.NetCore.Models
{
    public class DonHang
    {
        public int Id { get; set; }
        public int NguoiDungId { get; set; }
        public NguoiDung NguoiDung { get; set; }
        public DateTime NgayDat { get; set; } = DateTime.Now;
        public decimal TongTien { get; set; }
        public string TrangThai { get; set; } 
        public List<ChiTietDonHang> ChiTietDonHangs { get; set; } = new();
    }
}
