﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class SanPhamController : Controller
{
    private readonly ApplicationDbContext _context;

    public SanPhamController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index(string q, string thuongHieu)
    {
        var brands = await _context.Products.Select(p => p.Brand).Distinct().ToListAsync();

        IQueryable<SanPham> query = _context.Products.Include(p => p.ChiTietSanPham);

        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(p => p.Name.Contains(q) || p.Description.Contains(q));

        if (!string.IsNullOrWhiteSpace(thuongHieu) && thuongHieu != "Tất cả")
            query = query.Where(p => p.Brand == thuongHieu);

        var list = await query.OrderByDescending(p => p.IsFeatured).ToListAsync();

        ViewBag.Brands = brands;
        ViewBag.Search = q;
        ViewBag.SelectedBrand = thuongHieu ?? "Tất cả";

        return View(list);
    }

    
    public async Task<IActionResult> Details(int id)
    {
        var product = await _context.Products
            .Include(p => p.ChiTietSanPham) 
            .FirstOrDefaultAsync(p => p.Id == id);

        if (product == null) return NotFound();

        return View(product);
    }
}
