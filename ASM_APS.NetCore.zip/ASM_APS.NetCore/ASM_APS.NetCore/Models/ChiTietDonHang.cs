﻿namespace ASM_APS.NetCore.Models
{
    public class ChiTietDonHang
    {
        public int Id { get; set; }
        public int DonHangId { get; set; }
        public DonHang DonHang { get; set; }
        public int SanPhamId { get; set; }
        public SanPham SanPham { get; set; }
        public int SoLuong { get; set; }
        public decimal Gia { get; set; }
    }
}
