﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ASM_APS.NetCore.Controllers
{
    [Route("admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        private bool IsAdmin() => HttpContext.Session.GetString("Role") == "Admin";

        // Dashboard
        [Route("dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            ViewBag.TongSanPham = await _context.Products.CountAsync();
            ViewBag.TongKhachHang = await _context.Users.Where(u => u.VaiTro == "KhachHang").CountAsync();
            ViewBag.TongDonHang = await _context.Orders.CountAsync();
            ViewBag.TongDoanhThu = await _context.Orders.SumAsync(o => (decimal?)o.TongTien) ?? 0;

            return View();
        }

        // Danh sách sản phẩm
        [Route("products")]
        public async Task<IActionResult> Products()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");
            var products = await _context.Products
                .Include(p => p.ChiTietSanPham)
                .ToListAsync();
            return View(products);
        }

        // Thêm sản phẩm - GET
        [Route("products/create")]
        public IActionResult Create()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");
            return View();
        }

        // Thêm sản phẩm - POST
        [HttpPost]
        [Route("products/create")]
        public async Task<IActionResult> Create(SanPham model, ChiTietSanPham chiTiet)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            try
            {
                model.CreatedAt = DateTime.Now;
                _context.Products.Add(model);
                await _context.SaveChangesAsync();

                // Tạo chi tiết sản phẩm
                if (chiTiet != null)
                {
                    chiTiet.SanPhamId = model.Id;
                    _context.chiTietSanPhams.Add(chiTiet);
                    await _context.SaveChangesAsync();
                }

                return RedirectToAction("Products");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Lỗi: " + ex.Message);
                return View(model);
            }
        }

        // Sửa sản phẩm - GET
        [Route("products/edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            var product = await _context.Products
                .Include(p => p.ChiTietSanPham)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null) return NotFound();

            return View(product);
        }

        // Sửa sản phẩm - POST
        [HttpPost]
        [Route("products/edit/{id}")]
        public async Task<IActionResult> Edit(int id, SanPham model)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            try
            {
                var product = await _context.Products
                    .Include(p => p.ChiTietSanPham)
                    .FirstOrDefaultAsync(p => p.Id == id);

                if (product == null) return NotFound();

                if (!ModelState.IsValid)
                    return View(product);

                // Cập nhật thông tin sản phẩm
                product.Name = model.Name;
                product.Description = model.Description;
                product.Brand = model.Brand;
                product.Price = model.Price;
                product.OriginalPrice = model.OriginalPrice;
                product.Stock = model.Stock;
                product.ImageUrl = model.ImageUrl;
                product.IsFeatured = model.IsFeatured;

                // Cập nhật hoặc tạo chi tiết sản phẩm
                if (product.ChiTietSanPham == null)
                {
                    var chiTiet = new ChiTietSanPham
                    {
                        SanPhamId = id,
                        Ram = Request.Form["ChiTietSanPham.Ram"].ToString(),
                        Chip = Request.Form["ChiTietSanPham.Chip"].ToString(),
                        Camera = Request.Form["ChiTietSanPham.Camera"].ToString(),
                        Screen = Request.Form["ChiTietSanPham.Screen"].ToString(),
                        Pin = Request.Form["ChiTietSanPham.Pin"].ToString(),
                        Storage = Request.Form["ChiTietSanPham.Storage"].ToString()
                    };
                    _context.chiTietSanPhams.Add(chiTiet);
                }
                else
                {
                    product.ChiTietSanPham.Ram = Request.Form["ChiTietSanPham.Ram"].ToString();
                    product.ChiTietSanPham.Chip = Request.Form["ChiTietSanPham.Chip"].ToString();
                    product.ChiTietSanPham.Camera = Request.Form["ChiTietSanPham.Camera"].ToString();
                    product.ChiTietSanPham.Screen = Request.Form["ChiTietSanPham.Screen"].ToString();
                    product.ChiTietSanPham.Pin = Request.Form["ChiTietSanPham.Pin"].ToString();
                    product.ChiTietSanPham.Storage = Request.Form["ChiTietSanPham.Storage"].ToString();
                }

                _context.Products.Update(product);
                await _context.SaveChangesAsync();

                return RedirectToAction("Products");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Lỗi: " + ex.Message);
                return View(model);
            }
        }

        // Xóa sản phẩm
        [HttpPost]
        [Route("products/delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            try
            {
                var product = await _context.Products
                    .Include(p => p.ChiTietSanPham)
                    .FirstOrDefaultAsync(p => p.Id == id);

                if (product == null) return NotFound();

                // Xóa chi tiết sản phẩm trước
                if (product.ChiTietSanPham != null)
                {
                    _context.chiTietSanPhams.Remove(product.ChiTietSanPham);
                }

                _context.Products.Remove(product);
                await _context.SaveChangesAsync();

                return RedirectToAction("Products");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Products");
            }
        }

        // Danh sách khách hàng
        [Route("customers")]
        public async Task<IActionResult> Customers()
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            var customers = await _context.Users
                .Where(u => u.VaiTro == "KhachHang")
                .OrderByDescending(u => u.NgayTao)
                .ToListAsync();

            return View(customers);
        }

        // Chi tiết khách hàng
        [Route("customers/{id}")]
        public async Task<IActionResult> CustomerDetail(int id)
        {
            if (!IsAdmin()) return RedirectToAction("Login", "Auth");

            var customer = await _context.Users
                .Include(u => u.DonHangs)
                .FirstOrDefaultAsync(u => u.Id == id && u.VaiTro == "KhachHang");

            if (customer == null) return NotFound();

            return View(customer);
        }
    }
}