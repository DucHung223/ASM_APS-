﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ASM_APS.NetCore.Controllers
{
    public class AuthController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AuthController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Trang Đăng nhập
        public IActionResult Login()
        {
            return View();
        }

        // POST: Xử lý Đăng nhập
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string email, string matKhau)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(matKhau))
            {
                ModelState.AddModelError("", "Vui lòng nhập email và mật khẩu");
                return View();
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email && u.MatKhau == matKhau);

            if (user == null)
            {
                ModelState.AddModelError("", "Email hoặc mật khẩu không chính xác");
                return View();
            }

            // Lưu thông tin vào Session
            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("Username", user.TenDangNhap ?? user.Email);
            HttpContext.Session.SetString("Email", user.Email);
            HttpContext.Session.SetString("HoTen", user.HoTen ?? "");
            HttpContext.Session.SetString("Role", user.VaiTro ?? "KhachHang");

            // Chuyển hướng theo role
            if (user.VaiTro == "Admin")
            {
                return RedirectToAction("Dashboard", "Admin");
            }

            return RedirectToAction("Index", "SanPham");
        }

        // GET: Trang Đăng ký
        public IActionResult Register()
        {
            return View();
        }

        // POST: Xử lý Đăng ký
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(string hoTen, string email, string matKhau, string xacNhanMatKhau)
        {
            // Kiểm tra validation
            if (string.IsNullOrWhiteSpace(hoTen))
            {
                ModelState.AddModelError("hoTen", "Vui lòng nhập họ tên");
                return View();
            }

            if (string.IsNullOrWhiteSpace(email))
            {
                ModelState.AddModelError("email", "Vui lòng nhập email");
                return View();
            }

            if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
            {
                ModelState.AddModelError("matKhau", "Mật khẩu phải có ít nhất 6 ký tự");
                return View();
            }

            if (matKhau != xacNhanMatKhau)
            {
                ModelState.AddModelError("xacNhanMatKhau", "Mật khẩu xác nhận không trùng khớp");
                return View();
            }

            // Kiểm tra email đã tồn tại
            if (await _context.Users.AnyAsync(u => u.Email == email))
            {
                ModelState.AddModelError("email", "Email này đã được đăng ký");
                return View();
            }

            // Tạo người dùng mới
            var user = new NguoiDung
            {
                TenDangNhap = email.Split('@')[0],
                Email = email,
                MatKhau = matKhau,
                HoTen = hoTen,
                VaiTro = "KhachHang",
                NgayTao = DateTime.Now
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Đăng ký thành công! Vui lòng đăng nhập";
            return RedirectToAction("Login");
        }

        // GET: Đăng xuất
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "SanPham");
        }
    }
}