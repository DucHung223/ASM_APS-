﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace ASM_APS.NetCore.Controllers
{
    public class DonHangController : Controller
    {
        private readonly ApplicationDbContext _context;
        private const string CartKey = "Cart";
        public DonHangController(ApplicationDbContext context) { _context = context; }

        private List<MucGioHang> GetCart() => string.IsNullOrEmpty(HttpContext.Session.GetString(CartKey)) ? new List<MucGioHang>() : JsonSerializer.Deserialize<List<MucGioHang>>(HttpContext.Session.GetString(CartKey));

        [HttpPost]
        public async Task<IActionResult> DatHang()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Auth");

            var cart = GetCart();
            if (!cart.Any()) return RedirectToAction("Index", "GioHang");

            var donHang = new DonHang
            {
                NguoiDungId = userId.Value,
                NgayDat = DateTime.Now,
                TrangThai = "Pending",
                ChiTietDonHangs = new List<ChiTietDonHang>()
            };

            decimal total = 0;
            foreach (var it in cart)
            {
                var sp = await _context.Products.FindAsync(it.SanPhamId);
                if (sp == null || sp.Stock < it.SoLuong) return BadRequest("Sản phẩm không đủ hàng");
                donHang.ChiTietDonHangs.Add(new ChiTietDonHang
                {
                    SanPhamId = sp.Id,
                    SoLuong = it.SoLuong,
                    Gia = sp.Price
                });
                total += sp.Price * it.SoLuong;
                sp.Stock -= it.SoLuong;
            }
            donHang.TongTien = total;
            _context.Orders.Add(donHang);
            await _context.SaveChangesAsync();

            HttpContext.Session.Remove(CartKey);
            return RedirectToAction("ChiTiet", new { id = donHang.Id });
        }

        public async Task<IActionResult> ChiTiet(int id)
        {
            var dh = await _context.Orders
                .Include(o => o.ChiTietDonHangs)
                .ThenInclude(d => d.SanPham)
                .Include(o => o.NguoiDung)
                .FirstOrDefaultAsync(o => o.Id == id);
            if (dh == null) return NotFound();
            return View(dh);
        }
        public async Task<IActionResult> DonHangCua()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Auth");

            var donHangs = await _context.Orders
                .Where(o => o.NguoiDungId == userId.Value)
                .Include(o => o.ChiTietDonHangs)
                .ThenInclude(d => d.SanPham)
                .OrderByDescending(o => o.NgayDat)
                .ToListAsync();

            return View(donHangs);
        }

    }
}
