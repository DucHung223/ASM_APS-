﻿using ASM_APS.NetCore.Models;
using Microsoft.EntityFrameworkCore;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<NguoiDung> Users { get; set; }
    public DbSet<SanPham> Products { get; set; }
    public DbSet<DonHang> Orders { get; set; }
    public DbSet<ChiTietDonHang> OrderDetails { get; set; }
    public DbSet<ChiTietSanPham> chiTietSanPhams { get; set; }
}
