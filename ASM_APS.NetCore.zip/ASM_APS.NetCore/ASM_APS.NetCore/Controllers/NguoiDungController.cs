﻿using ASM_APS.NetCore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ASM_APS.NetCore.Controllers
{
    public class NguoiDungController : Controller
    {
        private readonly ApplicationDbContext _context;

        public NguoiDungController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /NguoiDung
        public async Task<IActionResult> Index()
        {
            var list = await _context.Users.ToListAsync(); 
            return View(list);
        }

        // GET: /NguoiDung/ThongTin/5
        public async Task<IActionResult> ThongTin(int id)
        {
            var nd = await _context.Users
                .Include(x => x.DonHangs) 
                .FirstOrDefaultAsync(x => x.Id == id);

            if (nd == null) return NotFound();

            return View("ThongTin",nd);
        }
    }
}
